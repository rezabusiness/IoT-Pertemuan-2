#include <WiFi.h>
#include <HTTPClient.h>
#include "DHT.h"

// ================== KONFIGURASI PIN ==================
#define DHTPIN 4
#define DHTTYPE DHT22
#define LED_PIN 15

DHT dht(DHTPIN, DHTTYPE);

// ================== WIFI ==================
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// ================== THINGSPEAK ==================
String apiKey = "PZJBPO853B011TTV";
const char* server = "http://api.thingspeak.com/update";

// ================== SCAN WIFI ==================
void scanWiFi() {
  Serial.println("Scanning WiFi...");
  
  int n = WiFi.scanNetworks();
  
  if (n == 0) {
    Serial.println("Tidak ada WiFi ditemukan");
  } else {
    Serial.println("WiFi ditemukan:");
    
    for (int i = 0; i < n; ++i) {
      Serial.print(i + 1);
      Serial.print(". ");
      Serial.print(WiFi.SSID(i));
      Serial.print(" (");
      Serial.print(WiFi.RSSI(i));
      Serial.print(" dBm) ");
      
      if (WiFi.encryptionType(i) == WIFI_AUTH_OPEN) {
        Serial.println("[Open]");
      } else {
        Serial.println("[Encrypted]");
      }
      
      delay(10);
    }
  }
  
  Serial.println("-----------------------");
}

// ================== SETUP ==================
void setup() {
  Serial.begin(115200);
  
  pinMode(LED_PIN, OUTPUT);
  dht.begin();

  scanWiFi();

  Serial.println("Menghubungkan ke WiFi...");
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Terhubung");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());
}

// ================== LOOP ==================
void loop() {
  float suhu = dht.readTemperature();
  float kelembapan = dht.readHumidity();

  // Validasi pembacaan sensor
  if (isnan(suhu) || isnan(kelembapan)) {
    Serial.println("Gagal membaca data dari DHT22");
    delay(2000);
    return;
  }

  // Tampilkan ke Serial Monitor
  Serial.print("Suhu       : ");
  Serial.print(suhu);
  Serial.println(" °C");

  Serial.print("Kelembapan : ");
  Serial.print(kelembapan);
  Serial.println(" %");

  // Kontrol LED
  if (suhu > 30) {
    digitalWrite(LED_PIN, HIGH);
  } else {
    digitalWrite(LED_PIN, LOW);
  }

  // Kirim ke ThingSpeak
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;

    String url = String(server) +
                 "?api_key=" + apiKey +
                 "&field1=" + String(suhu) +
                 "&field2=" + String(kelembapan);

    http.begin(url);
    
    int httpResponseCode = http.GET();

    Serial.print("HTTP Response code: ");
    Serial.println(httpResponseCode);

    http.end();
  } else {
    Serial.println("WiFi tidak terhubung!");
  }

  Serial.println("----------------------");

  delay(15000); // wajib untuk ThingSpeak
}